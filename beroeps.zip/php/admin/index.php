<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home admin</title>
</head>
<body>
	<a href="product/product_toevoeg.php">toevoegen</a><br>
	<a href="uitlees_admin.php">uitlees</a>
</body>
</html>